<?php
session_start();
// Autocarga de archivos de configuración y modelos
require_once __DIR__ . '/../app/Config/Database.php';

// Cargar TODOS los Modelos
require_once __DIR__ . '/../app/Models/Model.php';
require_once __DIR__ . '/../app/Models/Usuario.php';
require_once __DIR__ . '/../app/Models/Libro.php';
require_once __DIR__ . '/../app/Models/Autor.php';
require_once __DIR__ . '/../app/Models/Prestamo.php';

// Cargar TODOS los Controladores
require_once __DIR__ . '/../app/Controllers/AuthController.php';
require_once __DIR__. '/../app/Controllers/LibroController.php';
require_once __DIR__ . '/../app/Controllers/AutorController.php'; 
require_once __DIR__ . '/../app/Controllers/PrestamoController.php'; 


// Conexión a la base de datos
$database = new Database();
$db = $database->getConnection();

// Inicializar controladores
$authController = new AuthController($db);
$libroController = new LibroController($db);
$autorController = new AutorController($db);
$prestamoController = new PrestamoController($db);


// ----------------------------------------------------------------
// FUNCIÓN DE AUTENTICACIÓN
// ----------------------------------------------------------------
/**
 * Verifica si el usuario está autenticado. Si no lo está, redirige al login.
 */
function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: index.php?route=login");
        exit();
    }
}

// ----------------------------------------------------------------
// Mapeo de Rutas (Conexión entre URL y Lógica)
// ----------------------------------------------------------------

$route = $_GET['route'] ?? 'home';
$route = htmlspecialchars(strip_tags($route)); 

switch ($route) {
    // --- Rutas de Autenticación (Públicas) ---
    case 'login':
        $authController->login(); 
        break;
    case 'register':
        $authController->register(); 
        break;
    case 'logout':
        $authController->logout();
        break;

    // --- Rutas de Libros (Protegidas) ---
    case 'libros':
        requireAuth();
        $libroController->index();
        break;
    case 'libros/create':
        requireAuth();
        $libroController->create();
        break;
    case 'libros/store': 
        requireAuth();
        $libroController->store();
        break;
    case 'libros/delete':
        requireAuth();
        $libroController->delete();
        break;

    // --- Rutas de Autores (Protegidas) ---
    case 'autores':
        requireAuth();
        $autorController->index();
        break;
    case 'autores/create':
        requireAuth();
        $autorController->create();
        break;
    case 'autores/store':
        requireAuth();
        $autorController->store();
        break;
    case 'autores/edit':
        requireAuth();
        $autorController->edit();
        break;
    case 'autores/update':
        requireAuth();
        $autorController->update();
        break;
    case 'autores/delete':
        requireAuth();
        $autorController->delete();
        break;

    // --- Rutas de Préstamos (Protegidas) ---
    case 'prestamos':
        requireAuth();
        $prestamoController->index();
        break;
    case 'prestamos/create':
        requireAuth();
        $prestamoController->create();
        break;
    case 'prestamos/store':
        requireAuth();
        $prestamoController->store();
        break;
    case 'prestamos/return': // Ruta para procesar la devolución
        requireAuth();
        $prestamoController->returnLoan();
        break;

    // --- Ruta de Inicio ---
    case 'home':
    default:
        require_once __DIR__ . '/../views/home.php';
        break;
}
?>