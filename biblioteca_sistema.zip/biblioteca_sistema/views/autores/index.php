<?php require_once __DIR__ . '/../partials/header.php'; ?>
    <h2>Gestión de Autores</h2>

    <a href="index.php?route=autores/create" class="btn-create">Crear Nuevo Autor</a>
    
    <?php if (isset($_GET['message'])): ?>
        <p class="success-message"><?= htmlspecialchars($_GET['message']) ?></p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Nacionalidad</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($autores as $autor): ?>

                <tr>
                    <td><?= htmlspecialchars($autor['id_autor']) ?></td>
                    <td><?= htmlspecialchars($autor['nombre']) ?></td>
                    <td><?= htmlspecialchars($autor['nacionalidad']) ?></td>
                    <td>
                        <a href="index.php?route=autores/edit&id=<?= $autor['id_autor'] ?>">Editar</a> |
                        <a href="index.php?route=autores/delete&id=<?= $autor['id_autor'] ?>" 
                           onclick="return confirm('¿Seguro que deseas eliminar a este autor?');">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>