<?php require_once __DIR__ . '/../partials/header.php'; ?>

    <h2>Crear Nuevo Autor</h2>

    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <form action="index.php?route=autores/store" method="POST">
        <label for="nombre">Nombre Completo:</label>
        <input type="text" id="nombre" name="nombre" required><br>

        <label for="nacionalidad">Nacionalidad:</label>
        <input type="text" id="nacionalidad" name="nacionalidad"><br>

        <button type="submit" class="btn-primary">Guardar Autor</button>
        <a href="index.php?route=autores" class="btn-secondary">Cancelar</a>
    </form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
