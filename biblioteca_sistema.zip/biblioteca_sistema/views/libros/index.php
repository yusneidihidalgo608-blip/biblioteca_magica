<?php require_once __DIR__ . '/../partials/header.php'; ?>
    <h2>Gestión de Libros</h2>

    <a href="index.php?route=libros/create" class="btn-create">Crear Nuevo Libro</a>
    
    <?php if (isset($_GET['message'])): ?>
        <p class="success"><?= htmlspecialchars($_GET['message']) ?></p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Autor</th>
                <th>ISBN</th>
                <th>Stock</th>
                <th>Disp.</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($libros as $libro): ?>
                <tr>
                    <td><?= htmlspecialchars($libro['id_libro']) ?></td>
                    <td><?= htmlspecialchars($libro['titulo']) ?></td>
                    <td><?= htmlspecialchars($libro['nombre_autor']) ?></td>
                    <td><?= htmlspecialchars($libro['isbn']) ?></td>
                    <td><?= htmlspecialchars($libro['stock_total']) ?></td>
                    <td><?= htmlspecialchars($libro['stock_disponible']) ?></td>
                    <td>
                        <a href="index.php?route=libros/edit&id=<?= $libro['id_libro'] ?>">Editar</a> |
                        <a href="index.php?route=libros/delete&id=<?= $libro['id_libro'] ?>" 
                           onclick="return confirm('¿Seguro que deseas eliminar este libro?');">Eliminar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
