<?php require_once __DIR__ . '/../partials/header.php'; ?>

    <h2>Crear Nuevo Libro</h2>

    <form action="index.php?route=libros/store" method="POST">
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" required><br>

        <label for="isbn">ISBN:</label>
        <input type="text" id="isbn" name="isbn" required><br>
        
        <label for="anio_publicacion">Año de Publicación:</label>
        <input type="number" id="anio_publicacion" name="anio_publicacion" required><br>

        <label for="stock_total">Stock Total:</label>
        <input type="number" id="stock_total" name="stock_total" required min="1"><br>

        <label for="id_autor">Autor:</label>
        <select id="id_autor" name="id_autor" required>
            <option value="">-- Seleccione un autor --</option>
            <?php foreach ($autores as $autor): ?>
                <option value="<?= htmlspecialchars($autor['id_autor']) ?>">
                    <?= htmlspecialchars($autor['nombre']) ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <button type="submit">Guardar Libro</button>
    </form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
