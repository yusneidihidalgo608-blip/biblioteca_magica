<?php require_once __DIR__ . '/../partials/header.php'; ?>

    <h2>Editar Libro: <?= htmlspecialchars($libro['titulo']) ?></h2>

    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <form action="index.php?route=libros/update" method="POST">
        <input type="hidden" name="id_libro" value="<?= htmlspecialchars($libro['id_libro']) ?>">
        
        <label for="titulo">Título:</label>
        <input type="text" id="titulo" name="titulo" value="<?= htmlspecialchars($libro['titulo']) ?>" required><br>

        <label for="id_autor">Autor:</label>
        <select id="id_autor" name="id_autor" required>
            <option value="">-- Seleccione un autor --</option>
            <?php foreach ($autores as $autor): ?>
                <option value="<?= htmlspecialchars($autor['id_autor']) ?>"
                    <?= ($autor['id_autor'] == $libro['id_autor']) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($autor['nombre']) ?>
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="isbn">ISBN:</label>
        <input type="text" id="isbn" name="isbn" value="<?= htmlspecialchars($libro['isbn']) ?>"><br>

        <label for="anio_publicacion">Año de Publicación:</label>
        <input type="number" id="anio_publicacion" name="anio_publicacion" value="<?= htmlspecialchars($libro['anio_publicacion']) ?>" required><br>

        <label for="stock_total">Stock Total:</label>
        <input type="number" id="stock_total" name="stock_total" value="<?= htmlspecialchars($libro['stock_total']) ?>" min="1" required><br>
        
        <label for="stock_disponible">Stock Disponible:</label>
        <input type="number" id="stock_disponible" name="stock_disponible" value="<?= htmlspecialchars($libro['stock_disponible']) ?>" min="0" required><br>

        <button type="submit" class="btn-primary">Actualizar Libro</button>
        <a href="index.php?route=libros" class="btn-secondary">Cancelar</a>
    </form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
