<?php require_once __DIR__ . '/partials/header.php'; ?>

    <div class="hero">
        <h2>Bienvenido al Sistema de Gestión de Biblioteca</h2>
        <p>Utiliza el menú de navegación para administrar libros, autores y préstamos.</p>
        
        <?php if (isset($_SESSION['username'])): ?>
            <p>Has iniciado sesión como: <strong><?= htmlspecialchars($_SESSION['username']) ?></strong> (Rol: <?= htmlspecialchars($_SESSION['rol']) ?>)</p>
            <div class="dashboard-links">
                <a href="index.php?route=libros" class="btn-secondary">Gestionar Libros</a>
                <a href="index.php?route=prestamos" class="btn-secondary">Ver Préstamos Activos</a>
            </div>
        <?php else: ?>
            <p>Por favor, inicia sesión para acceder a las funcionalidades del sistema.</p>
            <a href="index.php?route=login" class="btn-primary">Iniciar Sesión</a>
        <?php endif; ?>
    </div>

<?php require_once __DIR__ . '/partials/footer.php'; ?>