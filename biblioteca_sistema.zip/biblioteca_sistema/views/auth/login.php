<?php 
// No incluye header/footer para ser una página de acceso independiente
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body class="auth-body">
    <div class="auth-container">
        <h2>Iniciar Sesión</h2>
        
        <?php if (isset($error)): ?>
            <p class="error-message"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        
        <?php if (isset($_GET['message'])): ?>
            <p class="success-message"><?= htmlspecialchars($_GET['message']) ?></p>
        <?php endif; ?>

        <form action="index.php?route=login" method="POST">
            <label for="nombre_usuario">Usuario:</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" required><br>

            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required><br>

            <button type="submit" class="btn-primary">Entrar</button>
        </form>

        <p class="link-auth">¿No tienes cuenta? <a href="index.php?route=register">Regístrate aquí</a></p>
    </div>
</body>
</html>