<?php 
// No incluye header/footer
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body class="auth-body">
    <div class="auth-container">
        <h2>Registro de Nuevo Usuario</h2>

        <?php if (isset($error)): ?>
            <p class="error-message"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form action="index.php?route=register" method="POST">
            <label for="nombre_completo">Nombre Completo:</label>
            <input type="text" id="nombre_completo" name="nombre_completo" required><br>

            <label for="nombre_usuario">Nombre de Usuario:</label>
            <input type="text" id="nombre_usuario" name="nombre_usuario" required><br>

            <label for="contrasena">Contraseña:</label>
            <input type="password" id="contrasena" name="contrasena" required><br>

            <button type="submit" class="btn-primary">Registrar</button>
        </form>

        <p class="link-auth">¿Ya tienes cuenta? <a href="index.php?route=login">Inicia Sesión</a></p>
    </div>
</body>
</html>