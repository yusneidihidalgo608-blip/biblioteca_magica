<?php require_once __DIR__ . '/../partials/header.php'; ?>

    <h2>Registrar Nuevo Préstamo</h2>

    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <form action="index.php?route=prestamos/store" method="POST">
        <label for="id_libro">Libro a Prestar (Stock Disponible > 0):</label>
        <select id="id_libro" name="id_libro" required>
            <option value="">-- Seleccione un libro --</option>
            <?php foreach ($libros as $libro): ?>
                <?php if ($libro['stock_disponible'] > 0): ?>
                    <option value="<?= htmlspecialchars($libro['id_libro']) ?>">
                        <?= htmlspecialchars($libro['titulo']) ?> (Disp: <?= $libro['stock_disponible'] ?>)
                    </option>
                <?php endif; ?>
            <?php endforeach; ?>
        </select><br>

        <label for="id_usuario">Usuario:</label>
        <select id="id_usuario" name="id_usuario" required>
            <option value="">-- Seleccione un usuario --</option>
            <?php foreach ($usuarios as $usuario): ?>
                <option value="<?= htmlspecialchars($usuario['id_usuario']) ?>">
                    <?= htmlspecialchars($usuario['nombre_completo']) ?> (<?= htmlspecialchars($usuario['nombre_usuario']) ?>)
                </option>
            <?php endforeach; ?>
        </select><br>

        <label for="fecha_devolucion_esperada">Fecha de Devolución Esperada:</label>
        <input type="date" id="fecha_devolucion_esperada" name="fecha_devolucion_esperada" required 
               min="<?= date('Y-m-d') ?>"><br>

        <button type="submit" class="btn-primary">Registrar Préstamo</button>
        <a href="index.php?route=prestamos" class="btn-secondary">Cancelar</a>
    </form>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
