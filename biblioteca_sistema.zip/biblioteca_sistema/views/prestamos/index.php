<?php require_once __DIR__ . '/../partials/header.php'; ?>
    <h2>Gestión de Préstamos Activos</h2>

    <a href="index.php?route=prestamos/create" class="btn-create">Registrar Nuevo Préstamo</a>
    
    <?php if (isset($_GET['message'])): ?>
        <p class="success-message"><?= htmlspecialchars($_GET['message']) ?></p>
    <?php endif; ?>
    <?php if (isset($_GET['error'])): ?>
        <p class="error-message"><?= htmlspecialchars($_GET['error']) ?></p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Libro</th>
                <th>Usuario</th>
                <th>Fecha Préstamo</th>
                <th>Devolución Esperada</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($prestamos as $prestamo): ?>
                <tr>
                    <td><?= htmlspecialchars($prestamo['id_prestamo']) ?></td>
                    <td><?= htmlspecialchars($prestamo['titulo_libro']) ?></td>
                    <td><?= htmlspecialchars($prestamo['nombre_usuario']) ?></td>
                    <td><?= htmlspecialchars($prestamo['fecha_prestamo']) ?></td>
                    <td><?= htmlspecialchars($prestamo['fecha_devolucion_esperada']) ?></td>
                    <td>
                        <?php 
                            // Lógica para determinar si está atrasado
                            $fecha_esperada = new DateTime($prestamo['fecha_devolucion_esperada']);
                            $hoy = new DateTime();
                            
                            if ($prestamo['estado'] === 'activo' && $fecha_esperada < $hoy) {
                                echo '<span style="color: red; font-weight: bold;">ATRASADO</span>';
                            } else {
                                echo htmlspecialchars($prestamo['estado']);
                            }
                        ?>
                    </td>
                    <td>
                        <?php if ($prestamo['estado'] !== 'devuelto'): ?>
                            <a href="index.php?route=prestamos/return&id=<?= $prestamo['id_prestamo'] ?>" 
                               onclick="return confirm('¿Confirmar devolución del libro?');" class="btn-primary">Devolver</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

<?php require_once __DIR__ . '/../partials/footer.php'; ?>
