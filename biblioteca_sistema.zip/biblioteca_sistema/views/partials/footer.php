</main>
    <footer>
        <p>&copy; <?= date('Y') ?> Gestión de Biblioteca. </p>
    </footer>
</body>
</html>