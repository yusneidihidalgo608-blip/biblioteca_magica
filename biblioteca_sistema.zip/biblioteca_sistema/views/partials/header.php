<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Gestión de Biblioteca</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <header>
        <h1>Gestión de Biblioteca</h1>
        <nav>
            <a href="index.php">Inicio</a>
            <a href="index.php?route=libros">Libros</a>
            <a href="index.php?route=autores">Autores</a>
            <a href="index.php?route=prestamos">Préstamos</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="index.php?route=logout">Cerrar Sesión</a>
            <?php else: ?>
                <a href="index.php?route=login">Iniciar Sesión</a>
            <?php endif; ?>
        </nav>
    </header>
    <main>