-- 1. Tabla Usuarios
CREATE TABLE Usuarios (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL, -- Almacenar hash de la contraseña
    nombre_completo VARCHAR(100) NOT NULL,
    rol ENUM('administrador', 'lector') NOT NULL DEFAULT 'lector',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabla Autores
CREATE TABLE Autores (
    id_autor INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    nacionalidad VARCHAR(50)
);

-- 3. Tabla Libros
CREATE TABLE Libros (
    id_libro INT AUTO_INCREMENT PRIMARY KEY,
    isbn VARCHAR(20) UNIQUE,
    titulo VARCHAR(255) NOT NULL,
    anio_publicacion YEAR,
    stock_total INT NOT NULL DEFAULT 0,
    stock_disponible INT NOT NULL DEFAULT 0,
    id_autor INT,
    FOREIGN KEY (id_autor) REFERENCES Autores(id_autor) ON DELETE SET NULL
);

-- 4. Tabla Préstamos
CREATE TABLE Prestamos (
    id_prestamo INT AUTO_INCREMENT PRIMARY KEY,
    id_libro INT NOT NULL,
    id_usuario INT NOT NULL,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion_esperada DATE NOT NULL,
    fecha_devolucion_real DATE NULL,
    estado ENUM('activo', 'devuelto', 'atrasado') NOT NULL DEFAULT 'activo',
    FOREIGN KEY (id_libro) REFERENCES Libros(id_libro) ON DELETE CASCADE,
    FOREIGN KEY (id_usuario) REFERENCES Usuarios(id_usuario) ON DELETE CASCADE
);

-- Insertar un usuario administrador por defecto (la contraseña es 'adminpass' hasheada con PASSWORD_DEFAULT)
-- *Nota Importante:* Reemplazar 'hashed_password_admin' con la contraseña hasheada real al crear el usuario.
INSERT INTO Usuarios (nombre_usuario, contrasena, nombre_completo, rol) 
VALUES ('admin', '$2y$10$Q78pD/7K4s8Lw5T0gW6gJ.k8eWn9B.k0L7jC5sN5G8', 'Administrador Principal', 'administrador'); 
-- Contraseña de ejemplo hasheada: adminpass