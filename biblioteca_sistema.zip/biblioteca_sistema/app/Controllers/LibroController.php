<?php
// Incluir dependencias
require_once __DIR__ . '/../Models/Libro.php';
require_once __DIR__. '/../Models/Autor.php'; // Necesario para la lista desplegable de autores

/**
 * Clase LibroController (Controlador)
 *
 * Maneja las solicitudes HTTP relacionadas con los Libros.
 */
class LibroController {
    private $libroModel;
    private $autorModel;

    /**
     * Constructor que inicializa los Modelos.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        $this->libroModel = new Libro($db);
        $this->autorModel = new Autor($db);
    }

    /**
     * Muestra la lista de todos los libros. (READ - L)
     */
    public function index() {
        // Lógica de negocio: Obtener todos los libros con el nombre del autor
        $libros = $this->libroModel->readAllWithAuthor();

        // Cargar la vista
        require_once __DIR__ . '/../../views/libros/index.php';
    }

    /**
     * Muestra el formulario para crear un nuevo libro.
     */
    public function create() {
        // Lógica de negocio: Obtener lista de autores para el select
        $autores = $this->autorModel->readAll(); 
        
        // Cargar la vista
        require_once __DIR__ . '/../../views/libros/create.php';
    }

    /**
     * Procesa la creación de un nuevo libro. (CREATE - C)
     */
    public function store() {
        // Verificar si se recibió el método POST
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Asignar datos del POST a las propiedades del Modelo
            $this->libroModel->isbn = $_POST['isbn'];
            $this->libroModel->titulo = $_POST['titulo'];
            $this->libroModel->anio_publicacion = $_POST['anio_publicacion'];
            $this->libroModel->stock_total = $_POST['stock_total'];
            $this->libroModel->stock_disponible = $_POST['stock_total']; // Inicialmente disponible = total
            $this->libroModel->id_autor = $_POST['id_autor'];

            // Lógica de negocio: Llamar al método de creación
            if ($this->libroModel->create()) {
                // Redirigir a la lista con un mensaje de éxito
                header("Location: index.php?route=libros&message=Libro creado exitosamente");
                exit();
            } else {
                // Manejo de errores
                header("Location: index.php?route=libros&error=Error al crear libro");
                exit();
            }
           
        }
    }

    // ... Implementar edit() para mostrar el formulario de edición ...
    // ... Implementar update() para procesar la actualización (UPDATE - U) ...

    /**
     * Procesa la eliminación de un libro. (DELETE - D)
     */
    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id && $this->libroModel->delete($id)) {
            header("Location: index.php?route=libros&message=Libro eliminado exitosamente");
            exit();
        }
        header("Location: index.php?route=libros&error=Error al eliminar libro");
        exit();
    }
}
// NOTA: Crear de manera similar AuthController.php, AutorController.php y PrestamoController.php
?>