<?php
require_once __DIR__ . '/../Models/Usuario.php';

/**
 * Clase AuthController (Controlador)
 *
 * Maneja el inicio de sesión, registro y cierre de sesión de los usuarios.
 */
class AuthController {
    private $usuarioModel;

    /**
     * Constructor que inicializa el Modelo de Usuario.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        $this->usuarioModel = new Usuario($db);
    }

    /**
     * Muestra el formulario de login o procesa la solicitud de inicio de sesión.
     */
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 1. Obtener datos del formulario
            $username = $_POST['nombre_usuario'] ?? '';
            $password = $_POST['contrasena'] ?? '';

            // 2. Buscar usuario en la base de datos
            $user = $this->usuarioModel->findByUsername($username);

            // 3. Verificar usuario y contraseña (Lógica de Negocio)
            if ($user && password_verify($password, $user['contrasena'])) {
                
                // Éxito: Crear la sesión
                $_SESSION['user_id'] = $user['id_usuario'];
                $_SESSION['username'] = $user['nombre_usuario'];
                $_SESSION['rol'] = $user['rol'];
                
                // Redirigir al inicio o a la gestión de libros
                header("Location: index.php?route=libros");
                exit();
            } else {
                // Falla: Mostrar error en el login
                $error = "Usuario o contraseña incorrectos.";
                require_once __DIR__ . '/../../views/auth/login.php';
            }
        } else {
            // Mostrar el formulario de login (GET)
            require_once __DIR__ . '/../../views/auth/login.php';
        }
    }

    /**
     * Muestra el formulario de registro o procesa la solicitud de registro.
     */
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // 1. Obtener y sanear datos
            $this->usuarioModel->nombre_usuario = trim($_POST['nombre_usuario']);
            $this->usuarioModel->nombre_completo = trim($_POST['nombre_completo']);
            $password = $_POST['contrasena'];
            
            // 2. Lógica de negocio: Hash de la contraseña (Seguridad)
            $this->usuarioModel->contrasena = password_hash($password, PASSWORD_DEFAULT);
            $this->usuarioModel->rol = 'lector'; // Asegurar rol por defecto

            // 3. Crear el usuario
            if ($this->usuarioModel->create()) {
                header("Location: index.php?route=login&message=Registro exitoso. Inicie sesión.");
                exit();
            } else {
                $error = "Error al registrar el usuario. El nombre de usuario podría ya existir.";
                require_once __DIR__ . '/../../views/auth/register.php';
            }
        } else {
            // Mostrar el formulario de registro (GET)
            require_once __DIR__ . '/../../views/auth/register.php';
        }
    }

    /**
     * Cierra la sesión del usuario y redirige al login.
     */
    public function logout() {
        // Destruir la sesión
        session_unset();
        session_destroy();
        
        // Redirigir al login
        header("Location: index.php?route=login");
        exit();

        header("Location: index.php?route=home");
        exit();

    }
}
?>