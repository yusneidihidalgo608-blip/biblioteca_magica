<?php
require_once __DIR__ . '/../Models/Autor.php';

/**
 * Clase AutorController (Controlador)
 * * Maneja las solicitudes HTTP relacionadas con los Autores (CRUD).
 */
class AutorController {
    private $autorModel;

    /**
     * Constructor que inicializa el Modelo de Autor.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        $this->autorModel = new Autor($db);
    }

    /**
     * Muestra la lista de todos los autores. (READ - L)
     */
    public function index() {
        $autores = $this->autorModel->readAll();
        require_once __DIR__ . '/../../views/autores/index.php';
    }

    /**
     * Muestra el formulario para crear un nuevo autor.
     */
    public function create() {
        require_once __DIR__ . '/../../views/autores/create.php';
    }

    /**
     * Procesa la creación de un nuevo autor. (CREATE - C)
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->autorModel->nombre = $_POST['nombre'] ?? '';
            $this->autorModel->nacionalidad = $_POST['nacionalidad'] ?? '';

            if ($this->autorModel->create()) {
                header("Location: index.php?route=autores&message=Autor creado exitosamente");
                exit();
            } else {
                header("Location: index.php?route=autores/create&error=Error al crear autor");
                exit();
            }
        }
    }

    /**
     * Muestra el formulario para editar un autor existente.
     */
    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header("Location: index.php?route=autores");
            exit();
        }

        $autor = $this->autorModel->readOne($id);
        if (!$autor) {
            header("Location: index.php?route=autores&error=Autor no encontrado");
            exit();
        }

        require_once __DIR__ . '/../../views/autores/edit.php';
    }

    /**
     * Procesa la actualización de un autor. (UPDATE - U)
     */
    public function update() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->autorModel->id_autor = $_POST['id_autor'] ?? null;
            $this->autorModel->nombre = $_POST['nombre'] ?? '';
            $this->autorModel->nacionalidad = $_POST['nacionalidad'] ?? '';

            if ($this->autorModel->update()) {
                header("Location: index.php?route=autores&message=Autor actualizado exitosamente");
                exit();
            } else {
                header("Location: index.php?route=autores/edit&id=" . $this->autorModel->id_autor . "&error=Error al actualizar autor");
                exit();
            }
        }
    }

    /**
     * Procesa la eliminación de un autor. (DELETE - D)
     */
    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id && $this->autorModel->delete($id)) {
            header("Location: index.php?route=autores&message=Autor eliminado exitosamente");
            exit();
        }
        header("Location: index.php?route=autores&error=Error al eliminar autor");
        exit();
    }
}
?>