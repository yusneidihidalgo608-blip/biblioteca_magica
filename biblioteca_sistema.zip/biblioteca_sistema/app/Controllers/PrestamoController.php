<?php
require_once __DIR__ . '/../Models/Prestamo.php';
require_once __DIR__ . '/../Models/Libro.php';
require_once __DIR__ . '/../Models/Usuario.php';

/**
 * Clase PrestamoController (Controlador)
 * * Maneja la lógica de Préstamos y Devoluciones.
 */
class PrestamoController {
    private $prestamoModel;
    private $libroModel;
    private $usuarioModel;

    /**
     * Constructor que inicializa los Modelos.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        $this->prestamoModel = new Prestamo($db);
        $this->libroModel = new Libro($db);
        $this->usuarioModel = new Usuario($db);
    }

    /**
     * Muestra la lista de préstamos activos.
     */
    public function index() {
        // Lógica de negocio: Obtener solo préstamos activos/atrasados
        $prestamos = $this->prestamoModel->readActiveLoans();
        
        // La vista mostrará los datos obtenidos
        require_once __DIR__ . '/../../views/prestamos/index.php';
    }

    /**
     * Muestra el formulario para registrar un nuevo préstamo.
     */
    public function create() {
        // Necesitamos listar libros disponibles y usuarios
        $libros = $this->libroModel->readAll(); // Podríamos filtrar por stock_disponible > 0
        $usuarios = $this->usuarioModel->readAll(); 
        
        require_once __DIR__ . '/../../views/prestamos/create.php';
    }

    /**
     * Procesa el registro de un nuevo préstamo.
     */
    public function store() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $id_libro = $_POST['id_libro'] ?? null;
            $id_usuario = $_POST['id_usuario'] ?? null;
            $fecha_esperada = $_POST['fecha_devolucion_esperada'] ?? null;

            if ($this->prestamoModel->createPrestamo($id_libro, $id_usuario, $fecha_esperada)) {
                header("Location: index.php?route=prestamos&message=Préstamo registrado y stock actualizado.");
                exit();
            } else {
                header("Location: index.php?route=prestamos/create&error=Error al registrar préstamo. Verifique el stock.");
                exit();
            }
        }
    }

    /**
     * Procesa la devolución de un préstamo.
     */
    public function returnLoan() {
        $id_prestamo = $_GET['id'] ?? null;
        
        if ($id_prestamo && $this->prestamoModel->devolverPrestamo($id_prestamo)) {
            header("Location: index.php?route=prestamos&message=Devolución registrada y stock incrementado.");
            exit();
        }
        header("Location: index.php?route=prestamos&error=Error al procesar la devolución.");
        exit();
    }
}
?>