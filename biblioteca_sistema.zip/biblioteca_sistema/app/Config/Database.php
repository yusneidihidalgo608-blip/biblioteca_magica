<?php
/**
 * Clase de Configuración de la Base de Datos
 *
 * Esta clase contiene las credenciales de conexión a MySQL.
 */
class Database {
    private $host = "localhost"; // Cambiar si es necesario
    private $db_name = "biblioteca_db"; // Nombre de la BD
    private $username = "root"; // Usuario de la BD
    private $password = ""; // Contraseña de la BD
    public $conn;

    /**
     * Obtiene la conexión a la base de datos.
     * @return PDO|null Objeto PDO de la conexión o null si falla.
     */
    public function getConnection() {
        $this->conn = null;
        try {
            // Documentación: Creación de la instancia PDO
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->exec("set names utf8");
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $exception) {
            // Error de conexión documentado
            echo "Error de conexión a la base de datos: " . $exception->getMessage();
            die();
        }
        return $this->conn;
    }
}
?>