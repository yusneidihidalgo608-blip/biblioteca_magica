<?php
require_once 'Model.php';

/**
 * Clase Usuario (Modelo)
 * * Gestiona la lógica de datos de la tabla 'Usuarios', incluyendo el registro y la búsqueda.
 */
class Usuario extends Model {
    protected $table_name = "Usuarios";
    protected $pk_name = "id_usuario";

    public $id_usuario;
    public $nombre_usuario;
    public $contrasena;
    public $nombre_completo;
    public $rol = 'lector'; // Rol por defecto

    /**
     * Constructor: Hereda la conexión de Model.php.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        parent::__construct($db);
    }

    /**
     * Busca un usuario por su nombre de usuario.
     * @param string $username El nombre de usuario a buscar.
     * @return array|bool El registro del usuario o false si no se encuentra.
     */
    public function findByUsername($username) {
        $query = "SELECT id_usuario, nombre_usuario, contrasena, rol, nombre_completo 
                  FROM " . $this->table_name . " 
                  WHERE nombre_usuario = :username 
                  LIMIT 0,1";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Crea un nuevo registro de Usuario.
     * * Nota: La contraseña debe ser hasheada antes de llamar a este método.
     * @return bool True si se creó, false si falló.
     */
    public function create() {
        // Consulta SQL para inserción
        $query = "INSERT INTO " . $this->table_name . " 
                  SET nombre_usuario=:username, contrasena=:password, 
                      nombre_completo=:fullname, rol=:rol";
        
        $stmt = $this->conn->prepare($query);

        // Sanear datos
        $this->nombre_usuario = htmlspecialchars(strip_tags($this->nombre_usuario));
        $this->nombre_completo = htmlspecialchars(strip_tags($this->nombre_completo));
        $this->rol = htmlspecialchars(strip_tags($this->rol));
        // La contraseña (ya hasheada) no necesita strip_tags

        // Vincular parámetros
        $stmt->bindParam(":username", $this->nombre_usuario);
        $stmt->bindParam(":password", $this->contrasena);
        $stmt->bindParam(":fullname", $this->nombre_completo);
        $stmt->bindParam(":rol", $this->rol);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>