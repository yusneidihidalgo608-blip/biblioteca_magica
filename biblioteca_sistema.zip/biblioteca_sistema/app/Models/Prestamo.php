<?php
require_once 'Model.php';

/**
 * Clase Prestamo (Modelo)
 * * Gestiona la lógica de datos de la tabla 'Prestamos' e interactúa con el stock de Libros.
 */
class Prestamo extends Model {
    protected $table_name = "Prestamos";
    protected $pk_name = "id_prestamo";

    public $id_prestamo;
    public $id_libro;
    public $id_usuario;
    public $fecha_prestamo;
    public $fecha_devolucion_esperada;
    public $fecha_devolucion_real;
    public $estado;

    /**
     * Constructor.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        parent::__construct($db);
    }

    /**
     * Registra un nuevo préstamo y actualiza el stock disponible del libro.
     * @param int $libro_id ID del libro a prestar.
     * @param int $usuario_id ID del usuario que toma prestado.
     * @param string $fecha_esperada Fecha en la que se espera la devolución.
     * @return bool True si el préstamo y la actualización de stock fueron exitosos.
     */
    public function createPrestamo($libro_id, $usuario_id, $fecha_esperada) {
        try {
            // Iniciar transacción (vital para la integridad del stock)
            $this->conn->beginTransaction();

            // 1. Verificar y Decrementar Stock del Libro (Lógica de Negocio)
            $query_stock = "UPDATE Libros 
                            SET stock_disponible = stock_disponible - 1 
                            WHERE id_libro = :id_libro AND stock_disponible > 0";
            $stmt_stock = $this->conn->prepare($query_stock);
            $stmt_stock->bindParam(":id_libro", $libro_id);
            $stmt_stock->execute();

            // Si no se actualizó ninguna fila (stock era 0), lanzar excepción
            if ($stmt_stock->rowCount() == 0) {
                $this->conn->rollBack();
                return false; // No hay stock o el ID es inválido
            }

            // 2. Registrar el Préstamo
            $query_prestamo = "INSERT INTO " . $this->table_name . " 
                               SET id_libro=:id_libro, id_usuario=:id_usuario, 
                                   fecha_prestamo=CURDATE(), fecha_devolucion_esperada=:fecha_esperada, 
                                   estado='activo'";
            $stmt_prestamo = $this->conn->prepare($query_prestamo);
            
            $stmt_prestamo->bindParam(":id_libro", $libro_id);
            $stmt_prestamo->bindParam(":id_usuario", $usuario_id);
            $stmt_prestamo->bindParam(":fecha_esperada", $fecha_esperada);
            $stmt_prestamo->execute();

            // Confirmar transacción
            $this->conn->commit();
            return true;

        } catch (Exception $e) {
            $this->conn->rollBack();
            // Logear o manejar el error
            // echo "Error en préstamo: " . $e->getMessage();
            return false;
        }
    }

    /**
     * Registra la devolución de un préstamo y actualiza el stock del libro.
     * @param int $prestamo_id ID del préstamo a devolver.
     * @return bool True si la devolución y la actualización de stock fueron exitosos.
     */
    public function devolverPrestamo($prestamo_id) {
        try {
            $this->conn->beginTransaction();
            
            // 1. Obtener ID del libro asociado al préstamo
            $query_get_libro = "SELECT id_libro FROM " . $this->table_name . " WHERE id_prestamo = :id AND estado = 'activo'";
            $stmt_get_libro = $this->conn->prepare($query_get_libro);
            $stmt_get_libro->bindParam(":id", $prestamo_id);
            $stmt_get_libro->execute();
            $result = $stmt_get_libro->fetch(PDO::FETCH_ASSOC);

            if (!$result) {
                $this->conn->rollBack();
                return false; // Préstamo no encontrado o ya devuelto
            }
            $libro_id = $result['id_libro'];

            // 2. Marcar el préstamo como devuelto (Lógica de Negocio)
            $query_devolucion = "UPDATE " . $this->table_name . " 
                                 SET fecha_devolucion_real = CURDATE(), estado = 'devuelto' 
                                 WHERE id_prestamo = :id";
            $stmt_devolucion = $this->conn->prepare($query_devolucion);
            $stmt_devolucion->bindParam(":id", $prestamo_id);
            $stmt_devolucion->execute();

            // 3. Incrementar Stock del Libro (Lógica de Negocio)
            $query_stock_inc = "UPDATE Libros 
                                SET stock_disponible = stock_disponible + 1 
                                WHERE id_libro = :id_libro";
            $stmt_stock_inc = $this->conn->prepare($query_stock_inc);
            $stmt_stock_inc->bindParam(":id_libro", $libro_id);
            $stmt_stock_inc->execute();

            // Confirmar transacción
            $this->conn->commit();
            return true;
            
        } catch (Exception $e) {
            $this->conn->rollBack();
            // echo "Error en devolución: " . $e->getMessage();
            return false;
        }
    }

    /**
     * Obtiene el listado de préstamos activos (un JOIN complejo para la vista).
     * @return array Listado de préstamos activos.
     */
    public function readActiveLoans() {
        $query = "SELECT 
                    p.id_prestamo, p.fecha_prestamo, p.fecha_devolucion_esperada, p.estado,
                    l.titulo AS titulo_libro, 
                    u.nombre_completo AS nombre_usuario
                  FROM " . $this->table_name . " p
                  JOIN Libros l ON p.id_libro = l.id_libro
                  JOIN Usuarios u ON p.id_usuario = u.id_usuario
                  WHERE p.estado = 'activo' OR p.estado = 'atrasado' 
                  ORDER BY p.fecha_devolucion_esperada ASC";
                  
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>