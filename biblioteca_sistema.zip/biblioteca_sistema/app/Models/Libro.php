<?php
// Incluir el modelo base
require_once 'Model.php';

/**
 * Clase Libro (Modelo)
 *
 * Maneja la lógica de datos específica para la tabla 'Libros'.
 */
class Libro extends Model {
    // Propiedades de la tabla Libros
    public $id_libro;
    public $isbn;
    public $titulo;
    public $anio_publicacion;
    public $stock_total;
    public $stock_disponible;
    public $id_autor;
    
    // Nombres de la tabla y PK
    protected $table_name = "Libros";
    protected $pk_name = "id_libro";

    /**
     * Constructor: Hereda la conexión de Model.php.
     */
    public function __construct($db) {
        parent::__construct($db);
    }

    /**
     * Crea un nuevo registro de Libro.
     * @return bool True si se creó, false si falló.
     */
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET isbn=:isbn, titulo=:titulo, anio_publicacion=:anio, 
                      stock_total=:s_total, stock_disponible=:s_disp, id_autor=:id_autor";
        
        $stmt = $this->conn->prepare($query);

        // Sanear datos (seguridad)
        $this->titulo = htmlspecialchars(strip_tags($this->titulo));
        // ... sanear el resto de propiedades ...

        // Vincular parámetros
        $stmt->bindParam(":isbn", $this->isbn);
        $stmt->bindParam(":titulo", $this->titulo);
        $stmt->bindParam(":anio", $this->anio_publicacion);
        $stmt->bindParam(":s_total", $this->stock_total);
        $stmt->bindParam(":s_disp", $this->stock_disponible);
        $stmt->bindParam(":id_autor", $this->id_autor);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    // ... Implementar update() similar a create() ...

    /**
     * Obtiene todos los libros con el nombre del autor.
     * @return array|bool Listado de libros con el nombre del autor.
     */
    public function readAllWithAuthor() {
        $query = "SELECT l.*, a.nombre AS nombre_autor 
                  FROM " . $this->table_name . " l
                  INNER JOIN Autores a ON l.id_autor = a.id_autor 
                  ORDER BY l.titulo ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
// NOTA: Crear de manera similar las clases Autor.php, Usuario.php, Prestamo.php.
?>