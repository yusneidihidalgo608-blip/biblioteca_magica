<?php
require_once 'Model.php';

/**
 * Clase Autor (Modelo)
 * * Gestiona la lógica de datos de la tabla 'Autores'.
 */
class Autor extends Model {
    protected $table_name = "Autores";
    protected $pk_name = "id_autor";

    public $id_autor;
    public $nombre;
    public $nacionalidad;

    /**
     * Constructor: Hereda la conexión de Model.php.
     * @param PDO $db Conexión a la base de datos.
     */
    public function __construct($db) {
        parent::__construct($db);
    }

    /**
     * Crea un nuevo registro de Autor. (CREATE)
     * @return bool True si se creó, false si falló.
     */
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  SET nombre=:nombre, nacionalidad=:nacionalidad";
        
        $stmt = $this->conn->prepare($query);

        // Sanear datos
        $this->nombre = htmlspecialchars(strip_tags($this->nombre));
        $this->nacionalidad = htmlspecialchars(strip_tags($this->nacionalidad));

        // Vincular parámetros
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":nacionalidad", $this->nacionalidad);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Actualiza un registro de Autor existente. (UPDATE)
     * @return bool True si se actualizó, false si falló.
     */
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET nombre=:nombre, nacionalidad=:nacionalidad 
                  WHERE id_autor = :id";
        
        $stmt = $this->conn->prepare($query);

        // Sanear datos y vincular
        $stmt->bindParam(":id", $this->id_autor);
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":nacionalidad", $this->nacionalidad);

        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>