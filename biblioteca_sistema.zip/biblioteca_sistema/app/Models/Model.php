<?php
/**
 * Clase Model Base (Clase Padre)
 *
 * Proporciona métodos genéricos de CRUD para todas las tablas.
 */
abstract class Model {
    protected $conn;
    protected $table_name; // Debe ser definido en las clases hijas
    protected $pk_name; // Nombre de la clave primaria (e.g., 'id_libro')

    /**
     * Constructor que inicializa la conexión a la base de datos.
     * @param PDO $db Conexión activa a la base de datos.
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Obtiene todos los registros de la tabla.
     * @return array|bool Arreglo de registros o false si falla.
     */
    public function readAll() {
        $query = "SELECT * FROM " . $this->table_name . " ORDER BY " . $this->pk_name . " DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Obtiene un registro por su ID (Clave Primaria).
     * @param int $id ID del registro a buscar.
     * @return array|bool Registro encontrado o false.
     */
    public function readOne($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE " . $this->pk_name . " = :id LIMIT 0,1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Nota: El método create() y update() se implementarán en las clases hijas
    // debido a que las columnas son específicas de cada tabla.
    
    /**
     * Elimina un registro por su ID (Clave Primaria).
     * @param int $id ID del registro a eliminar.
     * @return bool True si se eliminó, false en caso contrario.
     */
    public function delete($id) {
        $query = "DELETE FROM " . $this->table_name . " WHERE " . $this->pk_name . " = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }
}
?>